# Hyrule Cheat Menu v1.0.0 RC1

Created by fxbii.dev

Standalone release candidate for Windows Lichii Build 130 and Ocarina of Time Remake 1.1.1. Title ID `0400486024DEC000`, executable Build ID `E0F3CCFAF50065AE4EA01EB5AEB13B1A45DA3348`.

## Install and use

1. Close the game. In Lichii, right-click the game and choose **Open Mod Data Location**. Extract the `Hyrule-Cheat-Menu` folder there. Its `exefs` directory should contain `subsdk8` and the Build ID’s `.ips` file.
2. Launch the game and press **R3** in gameplay. Use D-pad Up/Down to select a row. The emulator’s configured Switch A toggles cheats and Switch B or R3 closes the menu. Use Lichii’s A/B settings to match the physical Xbox button labels if needed.
3. The first toggle requests one EXP confirmation per game session. Use D-pad Left/Right directly on Movement Speed. The four toggles and Movement Speed are independent.

| Cheat | Effect |
| --- | --- |
| God Mode | Replenishes the existing hearts and protects ordinary damage. |
| Infinite Rupees | Refills the current unlocked wallet. |
| Infinite Items | Refills eligible owned arrows, bombs, Bombchus, Deku Sticks, Deku Nuts, and Deku Seeds up to current capacity. |
| Infinite Magic | Replenishes an unlocked meter and intercepts ordinary magic costs. Greyed out without magic. |
| Movement Speed | Select 1×, 1.5×, 2×, or 3×. Changes were measured while walking, running, surface swimming, and climbing a ladder. |

To uninstall, close the game and remove the `Hyrule-Cheat-Menu` folder. To back up a save, close the game, right-click it in Lichii, open its save data location, and copy that directory. Resource refills can be included in subsequent normal game saves.

## Release candidate checks

- Cheats are marked EXP. Zero-count Deku items and Bombchus may need a positive quantity observed with the cheat active in the current save and age. The mod skips writes during scripted events. A minigame that keeps its script active may block R3.
- The native pause stops a live bomb fuse and keeps the last gameplay frame visible. The stock HUD reflects refills after the menu closes, and a full wallet can trigger the stock Navi prompt. Boss and timed-minigame pause still need testing. Savestate loads have no verified reset signal.
- Use one menu at a time with Fast Travel. Reserve `subsdk8` for Hyrule Cheat Menu and keep overlapping gameplay patches disabled.
- Speed targets ordinary movement. Special actions such as swim dashes use their stock movement paths. Child Link, wall climbing, and speed across FPS settings still need separate tests.
- On a copied save, compare movement on open ground, in deep water, and on a ladder at all four settings. Test a boss and a timed minigame, then reload the same save, another save, and from Game Over. The default is four toggles OFF and speed 1×. See `PROGRESS.md` in the source project for completed and pending tests.

## Rebuild

Use Python 3.9+ and Zig. Run `python build.py --main <pristine-uncompressed-main-NSO-dump> --zig <path-to-zig.exe>`. The build validates the game’s executable hash and hook signatures.
